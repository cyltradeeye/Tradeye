import express, { type Express } from 'express';
import cors from 'cors';
import signalsRouter from './routes/signals.js';

const app: Express = express();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.get('/api/healthz', (_req, res) => {
  res.json({ status: 'ok', time: new Date().toISOString() });
});

app.get('/api/test-telegram', async (_req, res) => {
  const token  = process.env['TELEGRAM_BOT_TOKEN'];
  const chatId = process.env['TELEGRAM_CHAT_ID'];
  if (!token || !chatId) {
    res.status(500).json({ success: false, error: 'Secrets manquants' });
    return;
  }
  const text = `🤖 Test TRADEYE\n✅ Connexion Telegram OK\n📅 ${new Date().toLocaleString('fr-FR')}`;
  try {
    const tgRes = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: chatId, text }),
    });
    const data = await tgRes.json();
    if (!tgRes.ok) { res.status(502).json({ success: false, error: data }); return; }
    res.json({ success: true, message: 'Message envoyé' });
  } catch (err) {
    res.status(500).json({ success: false, error: String(err) });
  }
});

app.use('/api', signalsRouter);

export default app;
