import { db, initDb } from '../db/index.js';
import { signalsTable } from '../db/schema.js';
import { eq, and, gte, sql } from 'drizzle-orm';

// ── Telegram ──────────────────────────────────────────────
const TG_TOKEN   = process.env['TELEGRAM_BOT_TOKEN'];
const TG_CHAT_ID = process.env['TELEGRAM_CHAT_ID'];

async function sendTelegram(text: string): Promise<void> {
  if (!TG_TOKEN || !TG_CHAT_ID) return;
  try {
    const res = await fetch(`https://api.telegram.org/bot${TG_TOKEN}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: TG_CHAT_ID, text, parse_mode: 'HTML' }),
    });
    if (!res.ok) console.warn(`[telegram] Erreur ${res.status}: ${await res.text()}`);
  } catch (err) {
    console.warn('[telegram] Échec (ignoré):', err);
  }
}

function formatDateFR(d: Date): string {
  const dd = String(d.getDate()).padStart(2,'0');
  const mm = String(d.getMonth()+1).padStart(2,'0');
  const hh = String(d.getHours()).padStart(2,'0');
  const min = String(d.getMinutes()).padStart(2,'0');
  return `${dd}/${mm}/${d.getFullYear()} ${hh}:${min}`;
}

function formatPrice(p: number): string {
  return p < 1 ? p.toFixed(6) : p < 100 ? p.toFixed(4) : p.toFixed(2);
}

// ── Types ─────────────────────────────────────────────────
interface Coin {
  rank: number; id: string; symbol: string; name: string; image: string;
  price: number; change: number; change1h: number;
  volume: number; mcap: number; volRatio: number;
}

// ── Scoring ───────────────────────────────────────────────
function scoreForLong(c: Coin): number {
  let score = 0;
  if (c.change1h > 0) { score += Math.min(40, (c.change1h / 5) * 40); }
  else { score -= 20; }
  if (c.change < -2 && c.change1h > 1) { score += 15; }
  else if (c.change > 0 && c.change1h > 0) { score += Math.min(15, (c.change / 10) * 15); }
  if (c.volRatio > 0) { score += Math.min(20, (c.volRatio / 0.4) * 20); }
  const avgH = c.change / 24;
  if (c.change1h > 0 && c.change1h > avgH * 2) score += 10;
  if (c.change > 15 && c.change1h < 0.5) score -= 10;
  if (c.change > 20) score -= 20;
  return Math.max(0, Math.min(100, score));
}

function scoreForShort(c: Coin): number {
  let score = 0;
  if (c.change1h < 0) { score += Math.min(40, (Math.abs(c.change1h) / 5) * 40); }
  else { score -= 20; }
  if (c.change > 3 && c.change1h < -1) { score += 15; }
  else if (c.change < -3 && c.change1h < 0) { score += Math.min(15, (Math.abs(c.change) / 10) * 15); }
  if (c.volRatio > 0 && c.change1h < 0) { score += Math.min(20, (c.volRatio / 0.4) * 20); }
  const avgH = c.change / 24;
  if (c.change1h < 0 && c.change1h < avgH * 2) score += 10;
  if (c.change < -15 && c.change1h < -3) score -= 12;
  if (c.change < -20) score -= 20;
  return Math.max(0, Math.min(100, score));
}

// ── Fetch CoinGecko ───────────────────────────────────────
const INTER_PAGE_DELAY_MS   = 2_000;
const RATE_LIMIT_BACKOFF_MS = 5 * 60 * 1000;

function sleep(ms: number) { return new Promise<void>(r => setTimeout(r, ms)); }

async function fetchPage(page: number): Promise<Record<string, unknown>[]> {
  const url = `https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=250&page=${page}&sparkline=false&price_change_percentage=1h,24h`;
  const res = await fetch(url);
  if (res.status === 429) throw Object.assign(new Error('CoinGecko 429'), { is429: true });
  if (!res.ok) throw new Error(`CoinGecko API error: ${res.status}`);
  return res.json() as Promise<Record<string, unknown>[]>;
}

async function fetchCoins(): Promise<Coin[]> {
  const p1 = await fetchPage(1);
  await sleep(INTER_PAGE_DELAY_MS);
  const p2 = await fetchPage(2);
  return [...p1, ...p2].map(c => ({
    rank:     (c.market_cap_rank as number) || 999,
    id:       c.id as string,
    symbol:   (c.symbol as string).toUpperCase(),
    name:     c.name as string,
    image:    c.image as string,
    price:    (c.current_price as number) || 0,
    change:   (c.price_change_percentage_24h as number) || 0,
    change1h: (c.price_change_percentage_1h_in_currency as number) || 0,
    volume:   (c.total_volume as number) || 0,
    mcap:     (c.market_cap as number) || 0,
    volRatio: (c.market_cap as number) > 0
      ? (c.total_volume as number) / (c.market_cap as number) : 0,
  }));
}

// ── Résolution signaux ────────────────────────────────────
const RESOLVE_AFTER_MS = 30 * 60 * 1000;

async function resolveSignals(coins: Coin[]) {
  const priceMap = new Map<string, number>(coins.map(c => [c.id, c.price]));
  const cutoff   = new Date(Date.now() - RESOLVE_AFTER_MS);
  const pending  = await db.select().from(signalsTable)
    .where(and(eq(signalsTable.resolved, false), sql`${signalsTable.createdAt} <= ${cutoff}`));

  for (const entry of pending) {
    const currentPrice = priceMap.get(entry.coinId);
    if (currentPrice == null) continue;
    const entryPrice = parseFloat(entry.entryPrice as unknown as string);
    const pct   = ((currentPrice - entryPrice) / entryPrice) * 100;
    const absPct = Math.abs(pct);
    const isCorrect = (entry.direction === 'long' && pct > 0.1) || (entry.direction === 'short' && pct < -0.1);
    const isNeutral = absPct <= 0.1;
    let result: string; let pts: number;
    if (isNeutral)       { result = 'neutral';   pts = 5; }
    else if (isCorrect)  { result = 'correct';   pts = absPct >= 2 ? 10 : absPct >= 1 ? 9 : absPct >= 0.5 ? 8 : absPct >= 0.3 ? 7 : 6; }
    else                 { result = 'incorrect'; pts = absPct >= 1 ? 0 : absPct >= 0.3 ? 2 : 3; }

    await db.update(signalsTable)
      .set({ resolved: true, result, exitPrice: String(currentPrice), pctChange: String(pct), pts })
      .where(eq(signalsTable.id, entry.id));

    const sign = pct >= 0 ? '+' : '';
    console.log(`[cron] Résolu: ${entry.symbol} ${entry.direction.toUpperCase()} → ${result} ${sign}${pct.toFixed(2)}% ${pts}pts`);
    const emoji = result === 'correct' ? '✅' : result === 'incorrect' ? '❌' : '➡️';
    await sendTelegram(
      `${emoji} RÉSULTAT — ${entry.symbol} ${entry.direction.toUpperCase()}\n` +
      `Entrée : $${formatPrice(entryPrice)} → Sortie : $${formatPrice(currentPrice)}\n` +
      `Variation : ${sign}${pct.toFixed(2)}%\n` +
      `Score : ${pts}/10 pts`
    );
  }
}

// ── Logger signal ─────────────────────────────────────────
const MIN_SCORE = 55;

async function logSignal(coin: Coin, direction: 'long' | 'short', score: number) {
  if (score < MIN_SCORE) return;
  const since = new Date(Date.now() - RESOLVE_AFTER_MS);
  const existing = await db.select({ id: signalsTable.id }).from(signalsTable)
    .where(and(eq(signalsTable.coinId, coin.id), eq(signalsTable.direction, direction), gte(signalsTable.createdAt, since)))
    .limit(1);
  if (existing.length > 0) return;

  const now = new Date();
  await db.insert(signalsTable).values({
    coinId: coin.id, symbol: coin.symbol, image: coin.image,
    direction, entryPrice: String(coin.price), signalScore: score, createdAt: now,
  });

  console.log(`[cron] Signal loggé: ${coin.symbol} ${direction.toUpperCase()} score=${score}/100 @ $${coin.price}`);
  const emoji = direction === 'long' ? '🟢' : '🔴';
  await sendTelegram(
    `${emoji} SIGNAL ${direction.toUpperCase()} — ${coin.symbol}\n` +
    `Score : ${score}/100\nPrix : $${formatPrice(coin.price)}\n` +
    `📅 ${formatDateFR(now)}\n⏱ Résolution dans 30min`
  );
}

// ── Cycle principal ───────────────────────────────────────
let isRunning = false;

async function runCycle() {
  if (isRunning) { console.log('[cron] Cycle déjà en cours, skip'); return; }
  isRunning = true;
  console.log(`[cron] Cycle @ ${new Date().toISOString()}`);
  try {
    const coins = await fetchCoins();
    console.log(`[cron] ${coins.length} coins récupérés`);
    await resolveSignals(coins);
    const tradeable = coins.filter(c => c.volume > 3_000_000);
    const scored    = tradeable.map(c => ({ ...c, lScore: scoreForLong(c), sScore: scoreForShort(c) }));
    const bestLong  = [...scored].sort((a,b) => b.lScore - a.lScore)[0];
    const bestShort = [...scored].sort((a,b) => b.sScore - a.sScore)[0];
    if (bestLong)  await logSignal(bestLong,  'long',  Math.round(bestLong.lScore));
    if (bestShort) await logSignal(bestShort, 'short', Math.round(bestShort.sScore));
  } catch (err: unknown) {
    const is429 = err instanceof Error && (err as Error & { is429?: boolean }).is429 === true;
    if (is429) { console.warn('[cron] 429 — pause 5min'); await sleep(RATE_LIMIT_BACKOFF_MS); }
    else { console.error('[cron] Erreur:', err); }
  } finally { isRunning = false; }
}

// ── Démarrage ─────────────────────────────────────────────
export async function startCron() {
  await initDb();
  console.log('[cron] Planificateur démarré (3min)');
  void runCycle();
  setInterval(() => { void runCycle(); }, 180_000);
}
