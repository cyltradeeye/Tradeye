import { Router } from 'express';
import { db } from '../db/index.js';
import { signalsTable } from '../db/schema.js';
import { eq, and, gte, desc } from 'drizzle-orm';

const router = Router();

function fmtDateFr(date: Date): string {
  const d  = String(date.getDate()).padStart(2,'0');
  const m  = String(date.getMonth()+1).padStart(2,'0');
  const hh = String(date.getHours()).padStart(2,'0');
  const mm = String(date.getMinutes()).padStart(2,'0');
  return `${d}/${m}/${date.getFullYear()} ${hh}:${mm}`;
}

// GET /api/signals/history
router.get('/signals/history', async (_req, res) => {
  try {
    const since = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const rows  = await db.select().from(signalsTable)
      .where(gte(signalsTable.createdAt, since)).orderBy(desc(signalsTable.createdAt));
    res.json({ success: true, data: rows.map(r => ({
      id: r.id, coin_id: r.coinId, symbol: r.symbol, image: r.image,
      direction: r.direction, entry_price: r.entryPrice, signal_score: r.signalScore,
      timestamp: r.createdAt.getTime(), created_at: r.createdAt.toISOString(),
      resolved: r.resolved, result: r.result, exit_price: r.exitPrice,
      pct_change: r.pctChange, pts: r.pts,
    }))});
  } catch (err) { res.status(500).json({ success: false, error: String(err) }); }
});

// GET /api/signals/pending
router.get('/signals/pending', async (_req, res) => {
  try {
    const rows = await db.select().from(signalsTable)
      .where(eq(signalsTable.resolved, false)).orderBy(desc(signalsTable.createdAt));
    res.json({ success: true, data: rows });
  } catch (err) { res.status(500).json({ success: false, error: String(err) }); }
});

// GET /api/signals/perfo
router.get('/signals/perfo', async (_req, res) => {
  try {
    const since7d = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    const rows    = await db.select().from(signalsTable)
      .where(and(eq(signalsTable.resolved, true), gte(signalsTable.createdAt, since7d)));
    const correct   = rows.filter(r => r.result === 'correct').length;
    const incorrect = rows.filter(r => r.result === 'incorrect').length;
    const neutral   = rows.filter(r => r.result === 'neutral').length;
    const withPts   = rows.filter(r => r.pts != null);
    const score7d   = withPts.length ? withPts.reduce((s,r) => s+(r.pts??0), 0) / withPts.length : null;
    const winRate   = rows.length ? (correct / rows.length) * 100 : null;
    res.json({ success: true, data: { correct, incorrect, neutral, total: rows.length, score7d, winRate }});
  } catch (err) { res.status(500).json({ success: false, error: String(err) }); }
});

// GET /api/signals/export
router.get('/signals/export', async (_req, res) => {
  try {
    const since    = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const rows     = await db.select().from(signalsTable)
      .where(gte(signalsTable.createdAt, since)).orderBy(desc(signalsTable.createdAt));
    const resolved = rows.filter(r => r.resolved);
    const pending  = rows.filter(r => !r.resolved);
    const correct  = resolved.filter(r => r.result === 'correct').length;
    const incorrect= resolved.filter(r => r.result === 'incorrect').length;
    const neutral  = resolved.filter(r => r.result === 'neutral').length;
    const withPts  = resolved.filter(r => r.pts != null);
    const score    = withPts.length ? (withPts.reduce((s,r) => s+(r.pts??0),0)/withPts.length).toFixed(1) : '—';
    const winRate  = resolved.length ? Math.round((correct/resolved.length)*100)+'%' : '—';
    const SEP = '='.repeat(52) + '\n';
    let txt = SEP + `  TRADEYE - HISTORIQUE SIGNAUX (30 JOURS)\n  Exporté le ${fmtDateFr(new Date())}\n` + SEP + '\n';
    txt += `SCORE GLOBAL 7J : ${score}/10\n`;
    txt += `CORRECTS : ${correct}  |  INCORRECTS : ${incorrect}  |  NEUTRES : ${neutral}\n`;
    txt += `WIN RATE : ${winRate}  |  TOTAL : ${resolved.length} signaux résolus\n\n`;
    txt += SEP + '  SIGNAUX EN COURS\n' + SEP + '\n';
    if (!pending.length) { txt += '  Aucun signal en cours\n\n'; }
    else { pending.forEach((r,i) => { const age = Math.floor((Date.now()-r.createdAt.getTime())/60000); txt += `[${i+1}] ${r.symbol} - ${r.direction.toUpperCase()} - Score ${r.signalScore}/100\n    Date : ${fmtDateFr(r.createdAt)} - il y a ${age}min\n    Entrée : $${r.entryPrice}\n\n`; }); }
    txt += SEP + '  SIGNAUX RÉSOLUS\n' + SEP + '\n';
    if (!resolved.length) { txt += '  Aucun signal résolu\n\n'; }
    else { resolved.forEach((r,i) => { const icon = r.result==='correct'?'OK':r.result==='neutral'?'->':'XX'; const pct = r.pctChange ? parseFloat(r.pctChange as unknown as string) : 0; const sign = pct>=0?'+':''; txt += `[${i+1}] ${icon} ${r.symbol} - ${r.direction.toUpperCase()} - Score ${r.signalScore}/100\n    Date : ${fmtDateFr(r.createdAt)}\n    Entrée : $${r.entryPrice}  ->  Sortie : $${r.exitPrice??'—'}\n    Résultat : ${sign}${pct.toFixed(2)}%  |  ${r.pts??'—'}/10 pts\n\n`; }); }
    txt += SEP + '  FIN DU RAPPORT\n' + SEP;
    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="tradeye_${new Date().toISOString().slice(0,10)}.txt"`);
    res.send(txt);
  } catch (err) { res.status(500).json({ success: false, error: String(err) }); }
});

export default router;
