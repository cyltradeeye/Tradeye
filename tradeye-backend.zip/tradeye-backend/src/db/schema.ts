import { pgTable, serial, text, integer, boolean, timestamp } from 'drizzle-orm/pg-core';

export const signalsTable = pgTable('signals', {
  id:          serial('id').primaryKey(),
  coinId:      text('coin_id').notNull(),
  symbol:      text('symbol').notNull(),
  image:       text('image').notNull(),
  direction:   text('direction').notNull(),
  entryPrice:  text('entry_price').notNull(),
  signalScore: integer('signal_score').notNull(),
  createdAt:   timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  resolved:    boolean('resolved').notNull().default(false),
  result:      text('result'),
  exitPrice:   text('exit_price'),
  pctChange:   text('pct_change'),
  pts:         integer('pts'),
});

export type Signal    = typeof signalsTable.$inferSelect;
export type NewSignal = typeof signalsTable.$inferInsert;
