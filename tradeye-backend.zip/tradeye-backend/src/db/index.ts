import { drizzle } from 'drizzle-orm/node-postgres';
import pkg from 'pg';
const { Pool } = pkg;

if (!process.env['DATABASE_URL']) {
  throw new Error('DATABASE_URL is required');
}

const pool = new Pool({
  connectionString: process.env['DATABASE_URL'],
  ssl: { rejectUnauthorized: false },
});

export const db = drizzle(pool);

// Initialise la table au démarrage
export async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS signals (
      id           SERIAL PRIMARY KEY,
      coin_id      TEXT NOT NULL,
      symbol       TEXT NOT NULL,
      image        TEXT NOT NULL,
      direction    TEXT NOT NULL,
      entry_price  TEXT NOT NULL,
      signal_score INTEGER NOT NULL,
      created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      resolved     BOOLEAN NOT NULL DEFAULT FALSE,
      result       TEXT,
      exit_price   TEXT,
      pct_change   TEXT,
      pts          INTEGER
    );
    CREATE INDEX IF NOT EXISTS idx_signals_coin_direction_time 
      ON signals (coin_id, direction, created_at);
  `);
  console.log('[db] Table signals prête');
}
