import app from './app.js';
import { startCron } from './services/cron.js';

const port = Number(process.env['PORT'] || 3000);

app.listen(port, () => {
  console.log(`[server] Listening on port ${port}`);
  startCron();
});
