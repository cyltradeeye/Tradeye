# TRADEYE Backend

Crypto signal engine — Express + TypeScript + PostgreSQL

## Variables d'environnement requises

```
DATABASE_URL=postgresql://...
TELEGRAM_BOT_TOKEN=...
TELEGRAM_CHAT_ID=...
PORT=3000
```

## Routes API

- GET /api/healthz — santé du serveur
- GET /api/signals/history — 30 derniers jours
- GET /api/signals/pending — signaux en cours
- GET /api/signals/perfo — score global
- GET /api/signals/export — téléchargement TXT
- GET /api/test-telegram — test bot Telegram
